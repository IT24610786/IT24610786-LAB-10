#include <cstdio>
#include <cstdlib>
#include <sys/time.h>
#include <cuda_runtime.h>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){ fprintf(stderr,"Error: %s:%d, code:%d, reason: %s\n",__FILE__,__LINE__,(int)e,cudaGetErrorString(e)); exit(1); } } while(0)
double cpuSecond(){ timeval t; gettimeofday(&t,nullptr); return (double)t.tv_sec+(double)t.tv_usec*1.e-6; }
#define NX 500
#define NY 500
#define NZ 500
__global__ void mulElem3D(const int*a,const int*b,int*c,int nx,int ny,int nz){int x=blockIdx.x*blockDim.x+threadIdx.x;int y=blockIdx.y*blockDim.y+threadIdx.y;int z=blockIdx.z*blockDim.z+threadIdx.z;if(x<nx&&y<ny&&z<nz){size_t idx=((size_t)z*ny+y)*nx+x;c[idx]=a[idx]*b[idx];}}
void random_ints(int*x,size_t n){for(size_t i=0;i<n;i++)x[i]=rand()%100;}
int main(){size_t count=(size_t)NX*NY*NZ,size=count*sizeof(int);int*a=(int*)malloc(size),*b=(int*)malloc(size),*c=(int*)malloc(size),*da,*db,*dc;if(!a||!b||!c){fprintf(stderr,"Host allocation failed\n");return 1;}
CHECK(cudaMalloc((void**)&da,size));CHECK(cudaMalloc((void**)&db,size));CHECK(cudaMalloc((void**)&dc,size));random_ints(a,count);random_ints(b,count);
CHECK(cudaMemcpy(da,a,size,cudaMemcpyHostToDevice));CHECK(cudaMemcpy(db,b,size,cudaMemcpyHostToDevice));dim3 threadsPerBlock(8,8,8);dim3 numBlocks((NX+7)/8,(NY+7)/8,(NZ+7)/8);printf("Grid: %u x %u x %u blocks\n",numBlocks.x,numBlocks.y,numBlocks.z);
double t=cpuSecond();mulElem3D<<<numBlocks,threadsPerBlock>>>(da,db,dc,NX,NY,NZ);CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());double elapsed=cpuSecond()-t;
CHECK(cudaMemcpy(c,dc,size,cudaMemcpyDeviceToHost));for(size_t i=count-1000;i<count;i++){size_t x=i%NX,y=(i/NX)%NY,z=i/((size_t)NX*NY);printf("C[%zu][%zu][%zu] = %d x %d = %d\n",z,y,x,a[i],b[i],c[i]);}
size_t errors=0;for(size_t i=0;i<count;i++)if(c[i]!=a[i]*b[i])errors++;printf("Verification: %zu mismatches out of %zu\nTime taken - %.7f\n",errors,count,elapsed);
free(a);free(b);free(c);CHECK(cudaFree(da));CHECK(cudaFree(db));CHECK(cudaFree(dc));return errors?1:0;}
