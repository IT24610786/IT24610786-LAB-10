#include <cstdio>
#include <cstdlib>
#include <sys/time.h>
#include <cuda_runtime.h>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){ fprintf(stderr,"Error: %s:%d, code:%d, reason: %s\n",__FILE__,__LINE__,(int)e,cudaGetErrorString(e)); exit(1); } } while(0)
double cpuSecond(){ timeval t; gettimeofday(&t,nullptr); return (double)t.tv_sec+(double)t.tv_usec*1.e-6; }
__global__ void add(const int*a,const int*b,int*c,size_t n){size_t i=(size_t)blockIdx.x*blockDim.x+threadIdx.x;if(i<n)c[i]=a[i]+b[i];}
__global__ void mul(const int*a,const int*b,int*c,size_t n){size_t i=(size_t)blockIdx.x*blockDim.x+threadIdx.x;if(i<n)c[i]=a[i]*b[i];}
#define N 100000000
int main(){size_t count=N,size=count*sizeof(int);int*a=(int*)malloc(size),*b=(int*)malloc(size),*c=(int*)malloc(size),*da,*db,*dc;if(!a||!b||!c)return 1;
for(size_t i=0;i<count;i++)a[i]=rand()%100;for(size_t i=0;i<count;i++)b[i]=rand()%100;
CHECK(cudaMalloc((void**)&da,size));CHECK(cudaMalloc((void**)&db,size));CHECK(cudaMalloc((void**)&dc,size));
double wholeStart=cpuSecond();CHECK(cudaMemcpy(da,a,size,cudaMemcpyHostToDevice));CHECK(cudaMemcpy(db,b,size,cudaMemcpyHostToDevice));
double kernelStart=cpuSecond();mul<<<(N+511)/512,512>>>(da,db,dc,N);CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());double kernelTime=cpuSecond()-kernelStart;
CHECK(cudaMemcpy(c,dc,size,cudaMemcpyDeviceToHost));double wholeTime=cpuSecond()-wholeStart;
size_t errors=0;for(size_t i=0;i<count;i++)if(c[i]!=a[i]*b[i])errors++;
printf("Verification: %zu mismatches out of %zu\nKernel only - %.7f s\nWhole copy-in/compute/copy-out - %.7f s\n",errors,count,kernelTime,wholeTime);
free(a);free(b);free(c);CHECK(cudaFree(da));CHECK(cudaFree(db));CHECK(cudaFree(dc));return errors?1:0;}
