#include <cstdio>
#include <cstdlib>
#include <sys/time.h>
#include <cuda_runtime.h>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){ fprintf(stderr,"Error: %s:%d, code:%d, reason: %s\n",__FILE__,__LINE__,(int)e,cudaGetErrorString(e)); exit(1); } } while(0)
double cpuSecond(){ timeval t; gettimeofday(&t,nullptr); return (double)t.tv_sec+(double)t.tv_usec*1.e-6; }
#define N 512
__global__ void add(int*a,int*b,int*c){c[blockIdx.x]=a[blockIdx.x]+b[blockIdx.x];}
int main(){int *a=(int*)malloc(N*4),*b=(int*)malloc(N*4),*c=(int*)malloc(N*4),*da,*db,*dc; if(!a||!b||!c)return 1;
for(int i=0;i<N;i++)a[i]=rand()%100;for(int i=0;i<N;i++)b[i]=rand()%100;
CHECK(cudaMalloc((void**)&da,N*4));CHECK(cudaMalloc((void**)&db,N*4));CHECK(cudaMalloc((void**)&dc,N*4));
CHECK(cudaMemcpy(da,a,N*4,cudaMemcpyHostToDevice));CHECK(cudaMemcpy(db,b,N*4,cudaMemcpyHostToDevice));
double t=cpuSecond();add<<<N,1>>>(da,db,dc);CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());double elapsed=cpuSecond()-t;
CHECK(cudaMemcpy(c,dc,N*4,cudaMemcpyDeviceToHost));for(int i=0;i<5;i++)printf("%d + %d = %d\n",a[i],b[i],c[i]);int errors=0;for(int i=0;i<N;i++)errors+=(c[i]!=a[i]+b[i]);
printf("Verification: %d mismatches out of %d\nTime taken - %.7f\n",errors,N,elapsed);
free(a);free(b);free(c);CHECK(cudaFree(da));CHECK(cudaFree(db));CHECK(cudaFree(dc));return errors?1:0;}
