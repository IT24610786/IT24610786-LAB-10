#include <cstdio>
#include <cstdlib>
#include <sys/time.h>
#include <cuda_runtime.h>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){ fprintf(stderr,"Error: %s:%d, code:%d, reason: %s\n",__FILE__,__LINE__,(int)e,cudaGetErrorString(e)); exit(1); } } while(0)
double cpuSecond(){ timeval t; gettimeofday(&t,nullptr); return (double)t.tv_sec+(double)t.tv_usec*1.e-6; }
#define N 512
__global__ void addBlocks(const int*a,const int*b,int*c){int i=blockIdx.x;c[i]=a[i]+b[i];}
int main(){size_t count=(size_t)N,size=count*sizeof(int);int*a=(int*)malloc(size),*b=(int*)malloc(size),*c=(int*)malloc(size),*da,*db,*dc;if(!a||!b||!c)return 1;
for(size_t i=0;i<count;i++)a[i]=rand()%100;for(size_t i=0;i<count;i++)b[i]=rand()%100;
CHECK(cudaMalloc((void**)&da,size));CHECK(cudaMalloc((void**)&db,size));CHECK(cudaMalloc((void**)&dc,size));
CHECK(cudaMemcpy(da,a,size,cudaMemcpyHostToDevice));CHECK(cudaMemcpy(db,b,size,cudaMemcpyHostToDevice));
double t=cpuSecond();addBlocks<<<512,1>>>(da,db,dc);CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());double elapsed=cpuSecond()-t;
CHECK(cudaMemcpy(c,dc,size,cudaMemcpyDeviceToHost));size_t errors=0;for(size_t i=0;i<count;i++)if(c[i]!=a[i]+b[i])errors++;
printf("Lab 9 Exercise 3: Verification: %zu mismatches out of %zu\nTime taken - %.7f\n",errors,count,elapsed);
free(a);free(b);free(c);CHECK(cudaFree(da));CHECK(cudaFree(db));CHECK(cudaFree(dc));return errors?1:0;}
