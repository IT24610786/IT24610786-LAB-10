# SE3082 Lab 10 — CUDA (Google Colab)

Student ID: IT24610786

## Files
- `ex1_timed.cu`: Exercise 1(a), synchronized kernel timing
- `lab9_ex3_timed.cu` through `lab9_ex6_timed.cu`: Exercise 1(b), run each three times
- `ex1c_copy_vs_kernel.cu`: Exercise 1(c), 100 million elements
- `ex2_check.cu`: Exercise 2, CHECK macro on all CUDA calls
- `ex3_picture.cu`: Exercise 3, 800x600 pixels, 2D grid
- `ex4_volume.cu`: Exercise 4, 500x500x500, 3D grid

## Colab usage
1. Runtime > Change runtime type > T4 GPU.
2. Upload the `.cu` files into Colab's Files sidebar (or use the included notebook).
3. Compile: `!nvcc -arch=sm_75 ex3_picture.cu -o ex3_picture`
4. Run: `!./ex3_picture`
5. Repeat with the other filenames. For Lab 9 timing runs, execute each binary three times.

**Important:** Source code is provided but was not executed on a GPU here. Record actual outputs and timings from Colab before submission. Exercise 2 experiments require temporarily editing the launch and allocation as described in the lab sheet. For Exercise 1's no-sync experiment, temporarily remove `cudaDeviceSynchronize()` in `ex1_timed.cu`, recompile, record timing, then restore it.

Large tests allocate up to 1.5 GB GPU memory and 1.5 GB host RAM, so allow time for initialization.
