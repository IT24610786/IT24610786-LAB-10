#include <cstdio>
#include <cstdlib>
#include <sys/time.h>
#include <cuda_runtime.h>
#define CHECK(call) do { cudaError_t e=(call); if(e!=cudaSuccess){ fprintf(stderr,"Error: %s:%d, code:%d, reason: %s\n",__FILE__,__LINE__,(int)e,cudaGetErrorString(e)); exit(1); } } while(0)
double cpuSecond(){ timeval t; gettimeofday(&t,nullptr); return (double)t.tv_sec+(double)t.tv_usec*1.e-6; }
#define WIDTH 800
#define HEIGHT 600
__global__ void PictureKernel(const unsigned char*in,unsigned char*out,int height,int width){int row=blockIdx.y*blockDim.y+threadIdx.y;int col=blockIdx.x*blockDim.x+threadIdx.x;if(row<height&&col<width){int v=2*in[row*width+col];out[row*width+col]=(unsigned char)(v>255?255:v);}}
int main(){size_t count=(size_t)WIDTH*HEIGHT,size=count*sizeof(unsigned char);auto h_in=(unsigned char*)malloc(size);auto h_out=(unsigned char*)malloc(size);if(!h_in||!h_out)return 1;unsigned char *d_in,*d_out;
CHECK(cudaMalloc((void**)&d_in,size));CHECK(cudaMalloc((void**)&d_out,size));for(size_t i=0;i<count;i++)h_in[i]=(unsigned char)(rand()%256);
CHECK(cudaMemcpy(d_in,h_in,size,cudaMemcpyHostToDevice));dim3 threadsPerBlock(16,16);dim3 numBlocks((WIDTH+15)/16,(HEIGHT+15)/16);
printf("Grid: %u x %u blocks of %u x %u threads\n",numBlocks.x,numBlocks.y,threadsPerBlock.x,threadsPerBlock.y);
double t=cpuSecond();PictureKernel<<<numBlocks,threadsPerBlock>>>(d_in,d_out,HEIGHT,WIDTH);CHECK(cudaGetLastError());CHECK(cudaDeviceSynchronize());double elapsed=cpuSecond()-t;
CHECK(cudaMemcpy(h_out,d_out,size,cudaMemcpyDeviceToHost));printf("Original top-left 50 x 50:\n");for(int y=0;y<50;y++){for(int x=0;x<50;x++)printf("%3d ",(int)h_in[y*WIDTH+x]);printf("\n");}
printf("Updated top-left 50 x 50:\n");for(int y=0;y<50;y++){for(int x=0;x<50;x++)printf("%3d ",(int)h_out[y*WIDTH+x]);printf("\n");}
size_t errors=0,capped=0;for(size_t i=0;i<count;i++){int v=2*(int)h_in[i];if(v>255){v=255;capped++;}if(h_out[i]!=v)errors++;}
printf("Verification: %zu mismatches out of %zu\nPixels capped at 255: %zu\nTime taken - %.7f\n",errors,count,capped,elapsed);
free(h_in);free(h_out);CHECK(cudaFree(d_in));CHECK(cudaFree(d_out));return errors?1:0;}
